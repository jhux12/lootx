PULLZ LOGO KIT

Primary colors
- Violet: #B90CFF
- Purple: #7538FF
- Royal blue: #356FFF
- Cyan blue: #08BDF3
- Navy: #071126
- White: #FFFFFF

Recommended use
- Dark website/header: PNG/pullz-horizontal-dark-2400.png or SVG/pullz-horizontal-dark.svg
- Light background: PNG/pullz-horizontal-light-2400.png or SVG/pullz-horizontal-light.svg
- Social profile/icon: PNG/pullz-icon-color-2048.png
- Browser favicon: Favicon/favicon-32.png and Favicon/favicon.svg
- iOS home icon: Favicon/apple-touch-icon-180.png
- Android/PWA: Favicon/android-chrome-192.png and android-chrome-512.png

Clear space
Keep empty space around the logo equal to at least half the height of the lowercase wordmark.

Minimum sizes
- Horizontal logo: 120 px wide on screens
- Icon: 24 px wide on screens

SVG notes
All icon geometry, colors, gradients, and text remain editable. The wordmark uses Nimbus Sans/Arial/Helvetica as fallbacks.
